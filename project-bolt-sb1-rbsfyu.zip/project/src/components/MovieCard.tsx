import React from 'react';
import { Play, Info } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { Movie } from '../types/movie';

interface MovieCardProps {
  movie: Movie;
}

export default function MovieCard({ movie }: MovieCardProps) {
  return (
    <Link to={`/movie/${movie.id}`} className="group relative">
      <div className="aspect-[2/3] overflow-hidden rounded-sm transition-transform duration-300 group-hover:scale-105 group-hover:z-10">
        <img
          src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
          alt={movie.title}
          className="h-full w-full object-cover"
        />
        <div className="movie-card-gradient absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="absolute bottom-0 left-0 right-0 p-4">
            <h3 className="text-lg font-medium mb-2">{movie.title}</h3>
            <div className="flex items-center gap-2">
              <button className="flex items-center gap-2 bg-white text-black rounded-full px-4 py-1 hover:bg-opacity-90">
                <Play size={16} fill="currentColor" />
                <span className="text-sm font-medium">Play</span>
              </button>
              <button className="flex items-center justify-center w-8 h-8 rounded-full border-2 border-gray-400 hover:border-white">
                <Info size={16} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}