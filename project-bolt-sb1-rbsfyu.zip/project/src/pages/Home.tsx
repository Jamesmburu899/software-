import React, { useEffect, useState } from 'react';
import { Play, Info } from 'lucide-react';
import MovieCard from '../components/MovieCard';
import SearchBar from '../components/SearchBar';
import { fetchTrending, searchMovies } from '../services/api';
import type { Movie } from '../types/movie';

export default function Home() {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [featuredMovie, setFeaturedMovie] = useState<Movie | null>(null);

  useEffect(() => {
    loadTrendingMovies();
  }, []);

  const loadTrendingMovies = async () => {
    const trending = await fetchTrending();
    setMovies(trending);
    setFeaturedMovie(trending[0]);
    setIsSearching(false);
  };

  const handleSearch = async (query: string) => {
    const results = await searchMovies(query);
    setMovies(results);
    setIsSearching(true);
  };

  return (
    <div className="min-h-screen bg-black">
      <header className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-b from-black/75 to-transparent">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-4xl font-bold text-red-600">JEMO</h1>
            <SearchBar onSearch={handleSearch} />
          </div>
        </div>
      </header>

      {!isSearching && featuredMovie && (
        <div className="relative h-[80vh] w-full">
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: `url(https://image.tmdb.org/t/p/original${featuredMovie.backdrop_path})`,
            }}
          >
            <div className="absolute inset-0 hero-gradient" />
            <div className="absolute bottom-1/4 left-0 p-12 max-w-2xl">
              <h2 className="text-5xl font-bold mb-4">{featuredMovie.title}</h2>
              <p className="text-lg text-gray-200 mb-6">{featuredMovie.overview}</p>
              <div className="flex items-center gap-4">
                <button className="flex items-center gap-2 bg-white text-black px-8 py-3 rounded hover:bg-opacity-90">
                  <Play size={24} fill="currentColor" />
                  <span className="font-medium">Play</span>
                </button>
                <button className="flex items-center gap-2 bg-gray-600/75 text-white px-8 py-3 rounded hover:bg-gray-600">
                  <Info size={24} />
                  <span className="font-medium">More Info</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <main className={`container mx-auto px-4 ${isSearching ? 'pt-24' : ''}`}>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-medium">
            {isSearching ? 'Search Results' : 'Trending Now'}
          </h2>
          {isSearching && (
            <button
              onClick={loadTrendingMovies}
              className="text-sm text-gray-400 hover:text-white"
            >
              Back to Trending
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
          {movies.map((movie) => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </div>
      </main>
    </div>
  );
}