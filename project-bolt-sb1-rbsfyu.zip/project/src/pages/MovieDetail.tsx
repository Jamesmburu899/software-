import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Play, Plus, ThumbsUp } from 'lucide-react';
import { getMovieDetails } from '../services/api';

export default function MovieDetail() {
  const { id } = useParams();
  const [movie, setMovie] = useState<any>(null);

  useEffect(() => {
    if (id) {
      getMovieDetails(id).then(setMovie);
    }
  }, [id]);

  if (!movie) return null;

  return (
    <div className="min-h-screen bg-black">
      <div className="relative h-[70vh]">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url(https://image.tmdb.org/t/p/original${movie.backdrop_path})`,
          }}
        >
          <div className="absolute inset-0 hero-gradient" />
        </div>
        <div className="absolute top-4 left-4">
          <Link
            to="/"
            className="flex items-center gap-2 text-white hover:text-gray-300 transition-colors"
          >
            <ArrowLeft size={24} />
          </Link>
        </div>
        <div className="absolute bottom-0 left-0 right-0 p-12">
          <h1 className="text-6xl font-bold mb-6">{movie.title}</h1>
          <div className="flex items-center gap-4 mb-8">
            <button className="flex items-center gap-2 bg-white text-black px-8 py-3 rounded hover:bg-opacity-90">
              <Play size={24} fill="currentColor" />
              <span className="font-medium">Play</span>
            </button>
            <button className="flex items-center justify-center w-12 h-12 rounded-full border-2 border-gray-400 hover:border-white">
              <Plus size={24} />
            </button>
            <button className="flex items-center justify-center w-12 h-12 rounded-full border-2 border-gray-400 hover:border-white">
              <ThumbsUp size={24} />
            </button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-12 py-8">
        <div className="flex gap-12">
          <div className="flex-1">
            <p className="text-lg text-gray-200 mb-6">{movie.overview}</p>
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-medium mb-2">Genres</h3>
                <div className="flex flex-wrap gap-2">
                  {movie.genres.map((genre: any) => (
                    <span
                      key={genre.id}
                      className="px-3 py-1 rounded-full bg-gray-800 text-gray-300"
                    >
                      {genre.name}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <div className="w-1/3">
            <div className="space-y-2 text-sm">
              <p className="text-gray-400">
                <span className="text-gray-600">Release Date: </span>
                {new Date(movie.release_date).toLocaleDateString()}
              </p>
              <p className="text-gray-400">
                <span className="text-gray-600">Runtime: </span>
                {movie.runtime} minutes
              </p>
              <p className="text-gray-400">
                <span className="text-gray-600">Rating: </span>
                {movie.vote_average.toFixed(1)}/10
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}